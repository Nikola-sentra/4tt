const OUTER_CSS = [
  'immersive-share-landing-page .container { padding-block-start: 0px !important; padding-block-end: 0px !important; padding-inline: 0px !important; }',
  'immersive-share-landing-page .page { max-width: 100% !important; width: 100% !important; }',
  'immersive-share-landing-page .preview-container { max-width: 100% !important; width: 100% !important; margin: 0 !important; padding: 0 !important; }',
  'immersive-share-landing-page .footer.footer-mobile { display: none !important; }',
  'button[data-test-id="copy-canvas-button"] { display: none !important; }',
  'body > div.boqOnegoogleliteOgbOneGoogleBar { display: none !important; }',
  '.side-nav-menu-button { display: none !important; }',
].join('\n');

const INNER_CSS = [
  'header#main-header { display: none !important; }',
  '.pt-28 { padding-top: 2px !important; }',
  '#restore-session-bar { display: none !important; }',
  'html, body { margin: 0 !important; padding: 0 !important; width: 100% !important; max-width: 100% !important; }',
  '#main-content { padding-inline: 0 !important; }',
  '#global-controls { padding: 0 !important; }',
  '.container { max-width: 100% !important; }',
  '.max-w-4xl, .max-w-2xl, .max-w-md { max-width: 100% !important; }',
].join('\n');

export const CHROME_UA =
  'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36';

export const UA_SPOOF_SCRIPT = `(function(){
  var ua = ${JSON.stringify(CHROME_UA)};
  try {
    Object.defineProperty(navigator, 'userAgent', { get: function(){ return ua; }, configurable: true });
  } catch (e) {}
  try {
    Object.defineProperty(navigator, 'appVersion', { get: function(){ return ua; }, configurable: true });
  } catch (e) {}
  try {
    Object.defineProperty(navigator, 'platform', { get: function(){ return 'Linux armv81'; }, configurable: true });
  } catch (e) {}
  try {
    Object.defineProperty(navigator, 'vendor', { get: function(){ return 'Google Inc.'; }, configurable: true });
  } catch (e) {}
  try {
    Object.defineProperty(navigator, 'maxTouchPoints', { get: function(){ return 10; }, configurable: true });
  } catch (e) {}
})();`;

export const CLEANER_SCRIPT = `(function(){
  var outerCss = ${JSON.stringify(OUTER_CSS)};
  var innerCss = ${JSON.stringify(INNER_CSS)};
  var logOnce = false;
  function addStyle(doc, css, id) {
    if (!doc || !doc.head) return false;
    if (id && doc.getElementById(id)) return true;
    var s = doc.createElement('style');
    s.type = 'text/css';
    if (id) s.id = id;
    s.textContent = css;
    doc.head.appendChild(s);
    return true;
  }
  function hideSubtitleTab(doc) { return; }
  function diag(extra) {
    try {
      if (logOnce) return;
      logOnce = true;
      var cssCount = document.querySelectorAll('#gcb-clean-css,#gcb-clean-frame-css').length;
      var panels = 0;
      var bodyKids = 0;
      var isCanvas = 0;
      var firstTitle = '';
      try {
        panels = document.querySelectorAll('.translator-panel').length;
        if (document.body) bodyKids = document.body.children.length;
        isCanvas = document.getElementById('main-content') ? 1 : 0;
        var ft = document.querySelector('.translator-panel h1');
        if (ft) firstTitle = (ft.textContent || '').replace(/[\\s]+/g, ' ').slice(0, 18);
      } catch (e) {}
      var msg = 'GCB[' + (isBlobTop ? 'B' : 'T') + ']' + document.readyState +
        '|' + String(window.location.href).slice(0, 58) +
        '|iw=' + window.innerWidth + '|sw=' + (document.documentElement ? document.documentElement.scrollWidth : '?') +
        '|sh=' + (document.documentElement ? document.documentElement.scrollHeight : '?') +
        '|css=' + cssCount + '|pan=' + panels + '|mc=' + isCanvas + '|body(' + bodyKids + '):' + (document.body ? String(document.body.className || '').slice(0, 24) : '?') + '|t=' + firstTitle + '|' + extra;
      if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
        window.ReactNativeWebView.postMessage(msg);
      }
      try { console.log('[GCB] ' + msg); } catch (e) {}
    } catch (e) {}
  }
  var isBlobTop = window.location.protocol === 'blob:';
  function healCanvas() {
    try {
      if (isBlobTop) return;
      if (!(document.querySelector('chat-app') || document.querySelector('chat-app-orchestrator'))) return;
      addStyle(document, 'chat-app, chat-app-orchestrator { padding-top: 0px !important; margin-top: 0px !important; }', 'gcb-canvas-heal-css');
      var best = null;
      var all = document.querySelectorAll('iframe');
      for (var i = 0; i < all.length; i++) {
        var r = all[i].getBoundingClientRect();
        if (r.width < 100 || r.height < 300) continue;
        if (!best || r.width * r.height > best.a) { best = { el: all[i], a: r.width * r.height }; }
      }
      if (!best) return;
      var el = best.el;
      el.style.position = 'fixed';
      el.style.top = '0';
      el.style.left = '0';
      el.style.width = '100%';
      el.style.height = '100%';
      el.style.maxWidth = 'none';
      el.style.maxHeight = 'none';
    } catch (e) {}
  }
  function clean() {
    var extra = '';
    if (isBlobTop) {
      addStyle(document, innerCss, 'gcb-clean-css');
      hideSubtitleTab(document);
      extra = 'blob-clean';
    } else {
      addStyle(document, outerCss, 'gcb-clean-css');
      healCanvas();
      extra = 'sb:' + (document.querySelector('immersive-share-landing-page') ? 1 : 0) + ' wp:' + (document.querySelector('web-preview') ? 1 : 0);
    }
    diag(extra);
  }
  clean();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', clean);
  }
  window.addEventListener('load', function(){ try { healCanvas(); } catch (e) {} });
  var attempts = 0;
  var retry = window.setInterval(function(){
    var a = document.activeElement;
    var typing = !!(a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA' || a.isContentEditable));
    if (!typing) clean();
    attempts++;
    if (attempts >= 40) window.clearInterval(retry);
  }, 600);
  window.setTimeout(function(){
    logOnce = false;
    try { diag('late'); } catch (e) {}
    logOnce = true;
  }, 8000);
})();`;

export const KEYBOARD_SCRIPT = `(function(){
  if (window.__gcbKeyFix) return;
  window.__gcbKeyFix = true;
  function isField(el){
    return !!(el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable ||
      (el.getAttribute && el.getAttribute('contenteditable') === 'true')));
  }
  function rootScroller(){
    return document.scrollingElement || document.documentElement;
  }
  function scrollerOf(field){
    var p = field;
    while (p && p !== document.body && p !== document.documentElement){
      if (p.scrollHeight > p.clientHeight + 2){
        var cs = null;
        try { cs = window.getComputedStyle(p); } catch(e){}
        if (cs && /(auto|scroll|overlay)/.test(cs.overflowY)) return p;
      }
      p = p.parentElement;
    }
    return rootScroller();
  }
  function capture(){
    var field = document.activeElement;
    if (!isField(field)) return null;
    var root = rootScroller();
    var sc = scrollerOf(field);
    return {
      rx: root.scrollLeft || 0,
      ry: root.scrollTop || 0,
      sc: sc,
      sx: sc.scrollLeft || 0,
      sy: sc.scrollTop || 0,
    };
  }
  function apply(rec){
    if (!rec) return;
    try {
      var root = rootScroller();
      if (root && (rec.rx || rec.ry)) { root.scrollLeft = rec.rx; root.scrollTop = rec.ry; }
      if (rec.sc && rec.sc !== root && (rec.sx || rec.sy)) { rec.sc.scrollLeft = rec.sx; rec.sc.scrollTop = rec.sy; }
    } catch(e){}
  }
  var saved = null;
  function hold(){
    var t = 0;
    var iv = window.setInterval(function(){
      apply(saved);
      t++;
      if (t >= 20) window.clearInterval(iv);
    }, 50);
  }
  document.addEventListener('focusin', function(ev){
    if (isField(ev.target)) {
      saved = capture();
      hold();
      window.setTimeout(function(){ apply(saved); }, 140);
      window.setTimeout(function(){ apply(saved); }, 340);
    }
  }, true);
  document.addEventListener('focusout', function(ev){
    if (isField(ev.target)) {
      apply(saved);
      saved = null;
    }
  }, true);
  document.addEventListener('touchstart', function(ev){
    if (saved && isField(ev.target)) saved = capture();
  }, true);
  document.addEventListener('touchend', function(ev){
    if (saved && isField(ev.target)) saved = capture();
  }, true);
  window.addEventListener('resize', function(){
    if (saved) window.setTimeout(function(){ apply(saved); }, 60);
  }, true);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', function(){
      if (saved) apply(saved);
    });
  }
})();`;

export const SCROLLBAR_SCRIPT = `(function(){
  if (window.__gcbScrollBar) return;
  window.__gcbScrollBar = true;
  var wrap = null;
  var thumb = null;
  var cached = null;
  function make(){
    if (wrap && wrap.isConnected) return;
    if (!document.body) return;
    var w = document.getElementById('gcb-scrollbar-wrap');
    if (w) { wrap = w; thumb = w.querySelector('#gcb-scrollbar-thumb'); return; }
    w = document.createElement('div');
    w.id = 'gcb-scrollbar-wrap';
    var tr = document.createElement('div');
    thumb = document.createElement('div');
    thumb.id = 'gcb-scrollbar-thumb';
    w.setAttribute('style',
      'position:fixed;top:0;right:2px;width:5px;height:100%;z-index:2147483647;pointer-events:none;' +
      'transition:opacity .15s;');
    tr.setAttribute('style',
      'position:absolute;top:0;bottom:0;left:0;right:0;border-radius:3px;background:rgba(15,23,42,0.08);');
    thumb.setAttribute('style',
      'position:absolute;top:0;left:0;width:5px;height:40px;border-radius:3px;' +
      'background:rgba(15,23,42,0.40);');
    tr.appendChild(thumb);
    w.appendChild(tr);
    document.body.appendChild(w);
    wrap = w;
  }
  function findScroller(){
    var se = document.scrollingElement || document.documentElement;
    if (se && se.scrollHeight > se.clientHeight + 2) { cached = se; return se; }
    if (cached && cached !== se && cached.isConnected && cached.scrollHeight > cached.clientHeight + 2){
      try {
        if (/(auto|scroll|overlay)/.test(window.getComputedStyle(cached).overflowY)) return cached;
      } catch(e){}
    }
    cached = null;
    var all = document.body ? document.body.querySelectorAll('*') : [];
    var best = null, bestSh = 0;
    for (var i = 0; i < all.length; i++){
      var n = all[i];
      if (n.scrollHeight > n.clientHeight + 2){
        var cs = null;
        try { cs = window.getComputedStyle(n); } catch(e){}
        if (cs && /(auto|scroll|overlay)/.test(cs.overflowY) && n.scrollHeight > bestSh){
          bestSh = n.scrollHeight;
          best = n;
        }
      }
    }
    cached = best;
    return best || se;
  }
  function isView(s, se){
    return s === se || s === document.documentElement;
  }
  function update(){
    if (!document.body) return;
    make();
    if (!wrap) return;
    var s = findScroller();
    if (!s) return;
    var se = document.scrollingElement || document.documentElement;
    if (s.scrollHeight <= s.clientHeight + 1){
      wrap.style.opacity = '0';
      return;
    }
    var top, ch, sh, st;
    if (isView(s, se)){
      top = 0;
      ch = window.innerHeight;
      sh = s.scrollHeight;
      st = s.scrollTop || window.pageYOffset || 0;
    } else {
      var r = s.getBoundingClientRect ? s.getBoundingClientRect() : { top: 0 };
      top = r.top;
      ch = s.clientHeight;
      sh = s.scrollHeight;
      st = s.scrollTop || 0;
    }
    var thumbH = Math.max(24, Math.round(ch * ch / sh));
    var maxT = Math.max(0, ch - thumbH);
    var ratio = (sh - ch) > 0 ? st / (sh - ch) : 0;
    var t = Math.round(ratio * maxT);
    wrap.style.top = Math.round(top) + 'px';
    wrap.style.height = Math.round(ch) + 'px';
    wrap.style.opacity = '1';
    thumb.style.height = thumbH + 'px';
    thumb.style.transform = 'translateY(' + t + 'px)';
  }
  try { make(); } catch(e){}
  document.addEventListener('DOMContentLoaded', function(){ make(); update(); });
  window.addEventListener('scroll', function(){ if (document.body) update(); }, true);
  window.addEventListener('resize', function(){ if (document.body) update(); }, true);
  window.addEventListener('touchstart', function(){ if (document.body) update(); }, true);
  window.addEventListener('touchend', function(){ if (document.body) update(); }, true);
  var iv = window.setInterval(function(){
    if (!document.body || !cached) { update(); return; }
    update();
  }, 600);
  window.setTimeout(function(){ window.clearInterval(iv); }, 30000);
})();`;

export const FIELDBAR_SCRIPT = `(function(){
  if (window.__gcbFieldBar) return;
  window.__gcbFieldBar = true;
  var bar = null;
  var thumb = null;
  var current = null;
  function isField(el){
    return !!(el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable ||
      (el.getAttribute && el.getAttribute('contenteditable') === 'true')));
  }
  function make(){
    if (bar && bar.isConnected) return;
    if (document.body && document.getElementById('gcb-fieldbar')) {
      bar = document.getElementById('gcb-fieldbar');
      return;
    }
    bar = document.createElement('div');
    bar.id = 'gcb-fieldbar';
    thumb = document.createElement('div');
    bar.setAttribute('style',
      'position:fixed;top:0;left:0;width:5px;height:40px;z-index:2147483646;pointer-events:none;' +
      'display:none;transition:opacity .12s;');
    thumb.setAttribute('style',
      'position:absolute;top:0;left:0;width:5px;height:40px;border-radius:3px;' +
      'background:rgba(15,23,42,0.45);');
    bar.appendChild(thumb);
    document.body.appendChild(bar);
  }
  function pageBar(){
    return document.getElementById('gcb-scrollbar-wrap');
  }
  function setPageOff(off){
    var pw = pageBar();
    if (pw) pw.style.opacity = off ? '0' : '';
  }
  function boxOf(field){
    if (field.scrollHeight > field.clientHeight + 1) return field;
    var p = field;
    while (p && p !== document.body && p !== document.documentElement){
      if (p.scrollHeight > p.clientHeight + 1){
        var cs = null;
        try { cs = window.getComputedStyle(p); } catch(e){}
        if (cs && /(auto|scroll|overlay)/.test(cs.overflowY)) return p;
      }
      p = p.parentElement;
    }
    return field;
  }
  function hide(){
    if (bar){ bar.style.display = 'none'; }
    setPageOff(false);
  }
  function update(){
    if (!document.body) return;
    make();
    if (!bar) return;
    if (!current || !current.isConnected || document.activeElement !== current){
      current = null;
      hide();
      return;
    }
    var box = boxOf(current);
    var sh = box.scrollHeight, ch = box.clientHeight;
    if (!(sh > ch + 1)){
      hide();
      return;
    }
    var r = box.getBoundingClientRect ? box.getBoundingClientRect() : null;
    if (!r || r.bottom < 0 || r.top > window.innerHeight){
      hide();
      return;
    }
    var thumbH = Math.max(20, Math.round(ch * ch / sh));
    var maxT = Math.max(0, ch - thumbH);
    var ratio = (sh - ch) > 0 ? (box.scrollTop || 0) / (sh - ch) : 0;
    var t = Math.round(ratio * maxT);
    bar.style.display = 'block';
    bar.style.top = Math.round(r.top) + 'px';
    bar.style.left = Math.round(r.left + r.width - 5) + 'px';
    bar.style.height = Math.round(ch) + 'px';
    bar.style.opacity = '1';
    thumb.style.height = thumbH + 'px';
    thumb.style.transform = 'translateY(' + t + 'px)';
    setPageOff(true);
  }
  document.addEventListener('focusin', function(ev){
    if (isField(ev.target)){
      current = ev.target;
      window.setTimeout(update, 40);
      window.setTimeout(update, 180);
    }
  }, true);
  document.addEventListener('focusout', function(ev){
    if (isField(ev.target) && ev.target === current){
      current = null;
      hide();
    }
  }, true);
  document.addEventListener('input', function(){ if (current) update(); }, true);
  document.addEventListener('keyup', function(){ if (current) update(); }, true);
  document.addEventListener('keydown', function(){ if (current) update(); }, true);
  document.addEventListener('pointerdown', function(){ if (current) update(); }, true);
  window.addEventListener('scroll', function(){ if (current) update(); }, true);
  window.addEventListener('resize', function(){ if (current) update(); }, true);
  window.addEventListener('touchstart', function(){ if (current) update(); }, true);
  window.addEventListener('touchend', function(){ if (current) update(); }, true);
  var iv = window.setInterval(function(){
    if (current && document.activeElement === current) update();
  }, 350);
  window.setTimeout(function(){ window.clearInterval(iv); }, 90000);
  try { make(); } catch(e){}
  document.addEventListener('DOMContentLoaded', function(){ try { make(); } catch(e){} });
})();`;

const INNER_LOGIC = `(function(){
  var isBlobTop = window.location.protocol === 'blob:';
  function addStyle(doc, css, id) {
    if (!doc || !doc.head) return false;
    if (id && doc.getElementById(id)) return true;
    var s = doc.createElement('style');
    s.type = 'text/css';
    if (id) s.id = id;
    s.textContent = css;
    doc.head.appendChild(s);
    return true;
  }
  var innerCss = ${JSON.stringify(INNER_CSS)};
  addStyle(document, innerCss, 'gcb-clean-css');
  function fwd(m) {
    try {
      if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
        window.ReactNativeWebView.postMessage(m);
      } else if (window.parent && window.parent !== window) {
        window.parent.postMessage({ __gcb: true, m: m }, '*');
      }
    } catch (e) {}
  }
  window.setTimeout(function(){ try { fwd('GCIJ|inner-ready|' + isBlobTop + '|ta=' + document.querySelectorAll('textarea').length + '|fld=' + document.querySelectorAll('input,textarea,[contenteditable="true"]').length); } catch (e) {} }, 400);
})();`;

export const PROXY_SCRIPT = `(function(){
  if (window.__gcbProxy) return;
  window.__gcbProxy = true;
  function post(m) {
    try {
      if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
        window.ReactNativeWebView.postMessage(m);
      }
    } catch (e) {}
  }
  function innerBundle() {
    return ${JSON.stringify(INNER_CSS)} + '|BODY|' + ${JSON.stringify(KEYBOARD_SCRIPT)} + ${JSON.stringify(SCROLLBAR_SCRIPT)} + ${JSON.stringify(FIELDBAR_SCRIPT)} + ${JSON.stringify(INNER_LOGIC)};
  }
  function injectInto(html) {
    var bundle = innerBundle();
    var head = bundle;
    if (html.indexOf('</head>') >= 0) {
      html = html.replace(/<\\/head>/i, '<script>' + bundle + '<\\/script><\\/head>');
    } else if (html.indexOf('<body') >= 0) {
      html = html.replace(/(<body[^>]*>)/i, '$1<script>' + bundle + '<\\/script>');
    } else {
      html = '<script>' + bundle + '<\\/script>' + html;
    }
    return html;
  }
  function handleShimMessage(msg) {
    try {
      if (!msg || typeof msg !== 'object') return;
      var mime = msg.mimeType;
      if (typeof mime === 'string' && mime.indexOf('text/html') !== 0) return;
      var body = msg.body;
      if (typeof body !== 'string' && !(body instanceof ArrayBuffer)) return;
      var html = typeof body === 'string' ? body : (function(){
        try { return new TextDecoder().decode(body); } catch(e){ return ''; }
      })();
      dbgpost(html);
      if (html.length < 3000) return;
      if (html.indexOf('</html>') < 0 && html.indexOf('</body>') < 0 && html.indexOf('<!doctype') < 0) return;
      var looksTool = html.indexOf('main-header') >= 0 || html.indexOf('translator-panel') >= 0 || html.indexOf('global-controls') >= 0;
      var injected = injectInto(html);
      if (typeof msg.body === 'string') {
        msg.body = injected;
      } else {
        try { msg.body = new TextEncoder().encode(injected).buffer; } catch(e){}
      }
      post('GPRX|injected|' + String(injected.length));
    } catch (e) {}
  }
  try {
    window.addEventListener('message', function(ev){
      try {
        if (ev && ev.data && ev.data.__gcb && ev.data.m) post('GCIJ:' + String(ev.data.m));
      } catch (e) {}
    }, true);
  } catch (e) {}
  function dbgpost(html) {
    try {
      var styleTags = (html.match(/<link[^>]*stylesheet[^>]*>/gi) || []).length;
      var inlineStyles = (html.match(/<style[^>]*>/gi) || []).length;
      var base = (html.match(/<base[^>]*href="([^"]*)"/i) || ['',''])[1].slice(0, 40);
      post('GPRXD|cssinfo lnk=' + styleTags + ' stl=' + inlineStyles + ' base=' + base + ' len=' + html.length);
    } catch (e) {}
  }
  window.__gcbHandleShimMessage = handleShimMessage;
  try {
    post('GPRX|proxy-start');
    var proto = HTMLIFrameElement.prototype;
    var realDesc = null;
    try { realDesc = Object.getOwnPropertyDescriptor(proto, 'contentWindow'); } catch (e) {}
    if (realDesc && realDesc.get && typeof Proxy !== 'undefined') {
      var origGet = realDesc.get;
      Object.defineProperty(proto, 'contentWindow', {
        configurable: true,
        enumerable: true,
        get: function(){
          if (this.__gcbProxyWin) return this.__gcbProxyWin;
          var real = null;
          try { real = origGet.call(this); } catch (e) {}
          if (!real) return real;
          post('GPRX|wrapper-hit');
          try {
            var target = real;
            var handler = {
              get: function(t, prop, recv){
                if (prop === 'postMessage') {
                  return function(msg, origin, transfer){
                    try { handleShimMessage(msg); } catch (e) {}
                    try { return target.postMessage(msg, origin, transfer); } catch (e) {}
                    return undefined;
                  };
                }
                try { return target[prop]; } catch (e) {}
                return undefined;
              }
            };
            var px = new Proxy(real, handler);
            this.__gcbProxyWin = px;
            return px;
          } catch (e) {
            return real;
          }
        }
      });
      post('GPRX|proxy-installed');
    } else {
      post('GPRXD|proxy-nodesc');
    }
  } catch (e) {
    post('GPRXD|proxy-err ' + String(e && e.message ? e.message : e));
  }
})();`;

export const CLEANER_MIN_SCRIPT = `(function(){
  var outerCss = ${JSON.stringify(OUTER_CSS)};
  function addStyle(doc, css, id) {
    if (!doc || !doc.head) return false;
    if (id && doc.getElementById(id)) return true;
    var s = doc.createElement('style');
    s.type = 'text/css';
    if (id) s.id = id;
    s.textContent = css;
    doc.head.appendChild(s);
    return true;
  }
  function healTop() {
    try {
      var url = String(window.location.href);
      if (url.indexOf('blob:') === 0) return;
      if (!(document.querySelector('chat-app') || document.querySelector('chat-app-orchestrator'))) return;
      addStyle(document, 'chat-app, chat-app-orchestrator { padding-top: 0px !important; margin-top: 0px !important; }', 'gcb-canvas-heal-css');
      var best = null;
      var all = document.querySelectorAll('iframe');
      for (var i = 0; i < all.length; i++) {
        var r = all[i].getBoundingClientRect();
        if (r.width < 100 || r.height < 300) continue;
        if (r.top > 2 && r.top < 200) {
          if (!best || r.width * r.height > best.a) { best = { el: all[i], a: r.width * r.height }; }
        }
      }
      if (!best) return;
      var el = best.el;
      el.style.position = 'fixed';
      el.style.top = '0';
      el.style.left = '0';
      el.style.width = '100%';
      el.style.height = '100%';
      el.style.maxWidth = 'none';
      el.style.maxHeight = 'none';
    } catch (e) {}
  }
  function diagOnce() {
    try {
      var msg = 'GCBM|' + document.readyState +
        '|' + String(window.location.href).slice(0, 52) +
        '|iw=' + window.innerWidth + '|sw=' + (document.documentElement ? document.documentElement.scrollWidth : '?') +
        '|sh=' + (document.documentElement ? document.documentElement.scrollHeight : '?') +
        '|wp=' + (document.querySelector('web-preview') ? 1 : 0) +
        '|sb=' + (document.querySelector('immersive-share-landing-page') ? 1 : 0);
      if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
        window.ReactNativeWebView.postMessage(msg);
      }
    } catch (e) {}
  }
  addStyle(document, outerCss, 'gcb-clean-css');
  healTop();
  diagOnce();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ healTop(); });
  }
  window.addEventListener('load', function(){ try { healTop(); } catch (e) {} });
  var hA = 0;
  var hI = window.setInterval(function(){
    hA++;
    try { healTop(); } catch (e) {}
    if (hA >= 30) window.clearInterval(hI);
  }, 400);
})();`;

export const DIAG_SCRIPT = `(function(){
  try {
    function probe(label){
      var out = {};
      out.l = label;
      function elinfo(x, y){
        try {
          var n = document.elementFromPoint(x, Math.max(0, y));
          if (!n) return null;
          var r = n.getBoundingClientRect ? n.getBoundingClientRect() : null;
          var bg = '';
          try { bg = getComputedStyle(n).backgroundColor; } catch(e){}
          var disp = '';
          try { disp = getComputedStyle(n).display; } catch(e){}
          return { tag: n.tagName.toLowerCase(), id: n.id || '', cls: String(n.className || '').slice(0, 42), y: r ? Math.round(r.top) : null, bg: bg, disp: disp };
        } catch(e){ return null; }
      }
      function boxOf(id){
        try {
          var n = document.getElementById(id);
          if (!n) return null;
          var r = n.getBoundingClientRect();
          return { y: Math.round(r.top), h: Math.round(r.height) };
        } catch(e){ return null; }
      }
      out.topW = elinfo(Math.floor(window.innerWidth / 2), 2);
      out.topL = elinfo(3, 2);
      out.topR = elinfo(window.innerWidth - 3, 2);
      out.tops = (function(){
        var arr = [];
        var seen = {};
        try {
          for (var y = 0; y <= 320; y += 4) {
            var n = document.elementFromPoint(Math.floor(window.innerWidth / 2), y);
            if (!n) continue;
            var key = n.tagName + (n.id ? '#' + n.id : '') + '.' + String(n.className || '').slice(0, 26);
            if (seen[key]) continue;
            seen[key] = 1;
            var r = n.getBoundingClientRect ? n.getBoundingClientRect() : null;
            var bg = '', disp = '';
            try { bg = getComputedStyle(n).backgroundColor; disp = getComputedStyle(n).display; } catch(e){}
            arr.push({ y: r ? Math.round(r.top) : null, k: key, h: r ? Math.round(r.height) : null, bg: bg, disp: disp });
            if (arr.length >= 10) break;
          }
        } catch(e){}
        return arr;
      })();
      out.chain = (function(){
        var arr = [];
        var fr = null;
        try {
          var all = document.querySelectorAll('iframe');
          var ifr = null;
          for (var i = 0; i < all.length; i++) {
            var r = all[i].getBoundingClientRect();
            if (r.width > 200 && r.height > 300) { ifr = all[i]; break; }
          }
          if (ifr) {
            var sameOrigin = false;
            try { sameOrigin = !!(ifr.contentDocument && ifr.contentDocument.body); } catch(e){ sameOrigin = false; }
            fr = { same: sameOrigin, src: String(ifr.getAttribute('src') || '').slice(0, 220), framesN: all.length };
          }
          if (ifr) {
            var el = ifr;
            var depth = 0;
            while (el && depth < 8) {
              var cs = el.getBoundingClientRect();
              var st = null;
              try { st = getComputedStyle(el); } catch(e){}
              arr.push({
                k: el.tagName + (el.id ? '#' + el.id : '') + '.' + String(el.className || '').slice(0, 24),
                y: Math.round(cs.top), h: Math.round(cs.height),
                pt: st ? st.paddingTop : null, mt: st ? st.marginTop : null,
                bg: st ? st.backgroundColor : null, disp: st ? st.display : null,
                pos: st ? st.position : null
              });
              el = el.parentElement; depth++;
            }
          }
        } catch(e){}
        out.fr = fr;
        return arr;
      })();
      try { out.frames = window.frames ? window.frames.length : 0; } catch(e){}
      try { out.iframes = document.querySelectorAll('iframe').length; } catch(e){}
      out.inner = (function(){
        var report = null;
        try {
          var ifr = null;
          var all = document.querySelectorAll('iframe');
          for (var i = 0; i < all.length; i++) {
            var r = all[i].getBoundingClientRect();
            if (r.width > 200 && r.height > 300) { ifr = all[i]; break; }
          }
          if (!ifr) return null;
          var d = null;
          try { d = ifr.contentDocument; } catch(e){}
          if (!d || !d.body) return null;
          var views = [];
          try {
            for (var v = 0; v < ifr.contentWindow.frames.length; v++) {
              var fw = ifr.contentWindow.frames[v];
              var fd = null;
              try { fd = fw.document; } catch(e){}
              if (fd && fd.body) views.push('frame' + v + ':' + String(fd.title || '').slice(0, 30) + '|ta=' + fd.querySelectorAll('textarea').length + '|fld=' + fd.querySelectorAll('input,textarea,[contenteditable="true"]').length + '|nifr=' + fd.querySelectorAll('iframe').length);
            }
          } catch(e){}
          var bodyCls = String(d.body ? d.body.className : '').slice(0, 40);
          var ta = d.querySelectorAll('textarea');
          var flds = d.querySelectorAll('input,textarea,[contenteditable="true"]');
          var hdr = d.getElementById('main-header');
          var hdrR = null;
          if (hdr) { try { var rr = hdr.getBoundingClientRect(); hdrR = Math.round(rr.top) + ':' + Math.round(rr.height); } catch(e){} }
          var innerIfr = d.querySelector('iframe');
          var innerIfrR = null;
          if (innerIfr) { try { var r2 = innerIfr.getBoundingClientRect(); innerIfrR = innerIfr.tagName + ' y=' + Math.round(r2.top) + ' h=' + Math.round(r2.height); } catch(e){} }
          var taInfo = null;
          if (ta.length) {
            try {
              var t0 = ta[0];
              var r3 = t0.getBoundingClientRect();
              taInfo = 'ta0 y=' + Math.round(r3.top) + ' h=' + Math.round(r3.height) + ' scH=' + t0.scrollHeight + ' clH=' + t0.clientHeight + ' sh=' + d.scrollingElement.scrollHeight + ' clh=' + d.scrollingElement.clientHeight;
            } catch(e){}
          }
          var innerUrl = null;
          try { innerUrl = String(ifr.contentWindow.location.href).slice(0, 160); } catch(e){}
          var innerTitle = null;
          try { innerTitle = String(d.title || '').slice(0, 50); } catch(e){}
          var innerKids = [];
          try {
            if (d.body) {
              var kids = d.body.querySelectorAll('header,main,section,article,#main-content,#global-controls,.translator-panel,[contenteditable="true"]');
              for (var k = 0; k < Math.min(kids.length, 6); k++) innerKids.push(kids[k].tagName + (kids[k].id ? '#' + kids[k].id : '') + '.' + String(kids[k].className || '').slice(0, 16));
            }
          } catch(e){}
          var innerPoint = null;
          try {
            var px = Math.floor(ifr.contentWindow.innerWidth / 2);
            var pn = ifr.contentDocument.elementFromPoint(px, 60);
            if (pn) innerPoint = pn.tagName + (pn.id ? '#' + pn.id : '') + '.' + String(pn.className || '').slice(0, 18);
          } catch(e){}
          report = { bodyCls: bodyCls, ta: ta.length, fld: flds.length, nifr: d.querySelectorAll('iframe').length, views: views, hdr: hdrR, innerIfr: innerIfrR, taInfo: taInfo, docSh: d.documentElement ? d.documentElement.scrollHeight : null, docCh: d.documentElement ? d.documentElement.clientHeight : null, url: innerUrl, title: innerTitle, kids: innerKids, pt60: innerPoint };
        } catch(e){}
        return report;
      })();
      out.hdr = boxOf('main-header');
      out.controls = boxOf('global-controls');
      out.main = boxOf('main-content');
      try { out.bodyM = getComputedStyle(document.body).marginTop; } catch(e){}
      out.ih = window.innerHeight;
      if (window.visualViewport) {
        out.vh = Math.round(window.visualViewport.height);
        out.voff = Math.round(window.visualViewport.offsetTop);
      }
      out.dpr = window.devicePixelRatio;
      if (window.screen) out.sh = window.screen.height;
      out.scY = Math.round(window.scrollY || document.documentElement.scrollTop || 0);
      var se = document.scrollingElement || document.documentElement;
      if (se) { out.docSh = se.scrollHeight; out.docCh = se.clientHeight; }
      try { out.u = String(window.location.href).slice(0, 60); } catch(e){}
      try {
        var ua = String(navigator.userAgent);
        out.pf = /Android/i.test(ua) ? 'android' : (/iPhone|iPad|iPod/i.test(ua) ? 'ios' : 'other');
      } catch(e){}
      var m = 'GCBD|' + JSON.stringify(out);
      try {
        if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
          window.ReactNativeWebView.postMessage(m);
        }
      } catch(e){}
      try { console.log('[GCB] ' + m); } catch(e){}
    }
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function(){ probe('dom'); });
    } else {
      probe('load');
    }
    window.setTimeout(function(){ probe('late2'); }, 2500);
    window.setTimeout(function(){ probe('late6'); }, 6000);
  } catch(e){}
})();`;

export const DOWNLOAD_SCRIPT = `(function(){
  function post(m) {
    try {
      if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
        window.ReactNativeWebView.postMessage(m);
      }
    } catch (e) {}
  }
  function sanitize(s) {
    return String(s || '').replace(/[<>:|"?*\\/\\n\\r]+/g, '_').trim() || 'download';
  }
  function send(name, mime, b64) {
    name = sanitize(name);
    var msg = 'GDL|' + encodeURIComponent(name) + '|' + (mime || 'application/octet-stream') + '|' + b64;
    var CH = 1000000;
    if (msg.length > 1800000) {
      for (var i = 0; i < msg.length; i += CH) {
        post('GDC|' + msg.slice(i, i + CH));
      }
      post('GCDE|' + msg.length);
    } else {
      post(msg);
    }
  }
  function handleBlob(href, name) {
    try {
      fetch(href).then(function (r) { return r.blob(); }).then(function (b) {
        if (b.size > 45 * 1024 * 1024) {
          post('GDE|' + encodeURIComponent(sanitize(name)));
          return;
        }
        var fr = new FileReader();
        fr.onload = function () {
          var dataUrl = String(fr.result || '');
          var c = dataUrl.indexOf(',');
          var base64 = c >= 0 ? dataUrl.slice(c + 1) : dataUrl;
          send(name, b.type, base64);
        };
        fr.readAsDataURL(b);
      }).catch(function () {});
    } catch (e) {}
  }
  function findAnchor(ev) {
    try {
      var path = ev.composedPath ? ev.composedPath() : (ev.path || []);
      for (var i = 0; i < path.length; i++) {
        var n = path[i];
        if (n && n.tagName === 'A') return n;
      }
    } catch (e) {}
    var t = ev.target;
    if (t && t.closest) {
      try { return t.closest('a'); } catch (e) {}
    }
    return null;
  }
  function grab(a) {
    var href = a.getAttribute && (a.getAttribute('href') || '');
    href = href || (a.href || '');
    if (href.indexOf('blob:') === 0) {
      handleBlob(href, a.getAttribute('download') || 'download');
      return true;
    }
    if (href.indexOf('data:') === 0) {
      var i = href.indexOf(',');
      var meta = href.slice(0, i).split(';');
      var mime0 = meta[0].replace('data:', '') || 'application/octet-stream';
      var raw = href.slice(i + 1);
      send(a.getAttribute('download') || 'download', mime0, raw);
      return true;
    }
    if (a.hasAttribute('target')) {
      if (href.indexOf('http') === 0) post('GCBLINK|' + href);
      return true;
    }
    return false;
  }
  document.addEventListener('click', function (ev) {
    var a = findAnchor(ev);
    if (!a) return;
    var href = a.getAttribute('href') || a.href || '';
    if (href.indexOf('blob:') !== 0 && href.indexOf('data:') !== 0 && !a.hasAttribute('target')) return;
    if (href.indexOf('blob:') !== 0 && href.indexOf('data:') !== 0 && !a.hasAttribute('download')) return;
    if (grab(a)) {
      ev.preventDefault();
      try { ev.stopPropagation(); } catch (e) {}
    }
  }, true);
  try {
    var origOpen = window.open;
    window.open = function (url, name) {
      var u = String(url || '');
      if (u.indexOf('blob:') === 0 || u.indexOf('data:') === 0) {
        handleBlob(u, name || 'download');
        return null;
      }
      if (u.indexOf('http') === 0) {
        post('GCBLINK|' + u);
        return null;
      }
      return origOpen ? origOpen.apply(this, arguments) : null;
    };
  } catch (e) {}
})();`;

export const UPLOAD_DIAG_SCRIPT = `(function(){
  if (window.__gcbUploadDiag) return;
  window.__gcbUploadDiag = true;
  function post(m) {
    try {
      if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
        window.ReactNativeWebView.postMessage(m);
      }
    } catch (e) {}
  }
  post('GUL|ready|' + location.origin.slice(0, 60));
  function desc(el) {
    var out = '';
    try {
      var tag = (el.tagName || '').toLowerCase();
      var tid = (el.id || '').slice(0, 20);
      var ari = (el.getAttribute && (el.getAttribute('aria-label') || '')) || '';
      var testid = (el.getAttribute && (el.getAttribute('data-test-id') || '')) || '';
      var cls = (el.className && el.className.baseVal !== undefined ? el.className.baseVal : el.className) || '';
      cls = String(cls).slice(0, 34);
      var txt = '';
      if (tag !== 'input' && tag !== 'textarea') {
        try { txt = String((el.textContent || '').trim()).replace(/\\s+/g, ' ').slice(0, 20); } catch (e) {}
      }
      out = tag + '#' + tid + '|' + ari + '|' + testid + '|' + cls + '|' + txt;
    } catch (e) { out = '?'; }
    return out.slice(0, 170);
  }
  function fileInputs() {
    var arr = [];
    try {
      var all = document.querySelectorAll('input[type=file]');
      for (var i = 0; i < all.length; i++) {
        var f = all[i];
        var r = null;
        try { r = f.getBoundingClientRect(); } catch (e) {}
        arr.push('i' + i + ':acc=' + (f.getAttribute('accept') || '') +
          ':x=' + (r ? Math.round(r.left) : '?') + ':y=' + (r ? Math.round(r.top) : '?') +
          ':w=' + (r ? Math.round(r.width) : '?') + ':h=' + (r ? Math.round(r.height) : '?') +
          ':v=' + (r && r.width > 0 && r.height > 0 ? 1 : 0));
      }
    } catch (e) {}
    return arr.join(',');
  }
  function scan(what) {
    post('GUL|scan|' + what + '|fi=' + document.querySelectorAll('input[type=file]').length + '|' + fileInputs());
  }
  try {
    document.addEventListener('pointerdown', function(ev){
      var t = ev.target;
      if (!t) return;
      var at = null;
      try { at = document.elementFromPoint(ev.clientX, ev.clientY); } catch (e) {}
      post('GUL|tap|' + Math.round(ev.clientX) + 'x' + Math.round(ev.clientY) + '|' + desc(t) + '|at=' + (at ? desc(at) : 'n/a'));
    }, true);
    document.addEventListener('change', function(ev){
      var t = ev.target;
      if (!t || !t.tagName) return;
      if ((t.tagName || '').toLowerCase() === 'input' && t.type === 'file') {
        var files = (t.files && t.files.length) || 0;
        var nm = files > 0 ? (String(t.files[0].name || '').slice(0, 40)) : '';
        var sz = files > 0 ? (t.files[0].size || 0) : 0;
        post('GUL|change-file|n=' + files + '|' + nm + '|' + sz + '|accept=' + (t.getAttribute('accept') || ''));
      }
    }, true);
    scan('t0');
    window.setTimeout(function(){ scan('t1500'); }, 1500);
    window.setTimeout(function(){ scan('t4000'); }, 4000);
    window.setTimeout(function(){ scan('t8000'); }, 8000);
  } catch (e) {}
})();`;