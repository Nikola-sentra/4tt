const OUTER_CSS = [
  'html, body { overflow: hidden !important; position: fixed !important; width: 100% !important; height: 100% !important; top: 0 !important; left: 0 !important; margin: 0 !important; padding: 0 !important; }',
  'immersive-share-landing-page .container { padding-block-start: 0px !important; padding-block-end: 0px !important; padding-inline: 0px !important; }',
  'immersive-share-landing-page .page { max-width: 100% !important; width: 100% !important; }',
  'immersive-share-landing-page .preview-container { max-width: 100% !important; width: 100% !important; margin: 0 !important; padding: 0 !important; }',
  'immersive-share-landing-page .footer.footer-mobile { display: none !important; }',
  'button[data-test-id="copy-canvas-button"] { display: none !important; }',
  'body > div.boqOnegoogleliteOgbOneGoogleBar { display: none !important; }',
  '.side-nav-menu-button { display: none !important; }',
].join('\n');

const INNER_CSS = [
  'header#main-header { display: none !important; }',
  '.pt-28 { padding-top: 2px !important; }',
  '#restore-session-bar { display: none !important; }',
  'html, body { margin: 0 !important; padding: 0 !important; width: 100% !important; max-width: 100% !important; }',
  '#main-content { padding-inline: 0 !important; }',
  '#global-controls { padding: 0 !important; }',
  '.container { max-width: 100% !important; }',
  '.max-w-4xl, .max-w-2xl, .max-w-md { max-width: 100% !important; }',
].join('\n');

export const CHROME_UA =
  'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36';

export const UA_SPOOF_SCRIPT = `(function(){
  var ua = ${JSON.stringify(CHROME_UA)};
  try { Object.defineProperty(navigator, 'userAgent', { get: function(){ return ua; }, configurable: true }); } catch (e) {}
  try { Object.defineProperty(navigator, 'appVersion', { get: function(){ return ua; }, configurable: true }); } catch (e) {}
  try { Object.defineProperty(navigator, 'platform', { get: function(){ return 'Linux armv81'; }, configurable: true }); } catch (e) {}
  try { Object.defineProperty(navigator, 'vendor', { get: function(){ return 'Google Inc.'; }, configurable: true }); } catch (e) {}
  try { Object.defineProperty(navigator, 'maxTouchPoints', { get: function(){ return 10; }, configurable: true }); } catch (e) {}
})();`;

export const KEYBOARD_SCRIPT = `(function(){
  if (window.__gcbKeyFix) return;
  window.__gcbKeyFix = true;

  function resetScroll() {
    try {
      if (window.scrollY !== 0 || window.scrollX !== 0) {
        window.scrollTo(0, 0);
      }
      if (document.documentElement && (document.documentElement.scrollTop !== 0 || document.documentElement.scrollLeft !== 0)) {
        document.documentElement.scrollTop = 0;
        document.documentElement.scrollLeft = 0;
      }
      if (document.body && (document.body.scrollTop !== 0 || document.body.scrollLeft !== 0)) {
        document.body.scrollTop = 0;
        document.body.scrollLeft = 0;
      }
    } catch(e){}
  }

  window.addEventListener('scroll', resetScroll, { passive: true });

  document.addEventListener('focusin', function() {
    resetScroll();
    setTimeout(resetScroll, 60);
    setTimeout(resetScroll, 200);
  }, true);

  document.addEventListener('focusout', function() {
    resetScroll();
    setTimeout(resetScroll, 60);
    setTimeout(resetScroll, 200);
  }, true);

  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', function() {
      resetScroll();
      setTimeout(resetScroll, 50);
      setTimeout(resetScroll, 150);
    });
  }
})();`;

export const CLEANER_SCRIPT = `(function(){
  var outerCss = ${JSON.stringify(OUTER_CSS)};
  var innerCss = ${JSON.stringify(INNER_CSS)};

  function addStyle(doc, css, id) {
    if (!doc || !doc.head) return false;
    if (id && doc.getElementById(id)) return true;
    var s = doc.createElement('style');
    s.type = 'text/css';
    if (id) s.id = id;
    s.textContent = css;
    doc.head.appendChild(s);
    return true;
  }

  var isBlobTop = window.location.protocol === 'blob:';

  function healCanvas() {
    try {
      if (isBlobTop) return;
      if (!(document.querySelector('chat-app') || document.querySelector('chat-app-orchestrator'))) return;
      addStyle(document, 'chat-app, chat-app-orchestrator { padding-top: 0px !important; margin-top: 0px !important; }', 'gcb-canvas-heal-css');
      var best = null;
      var all = document.querySelectorAll('iframe');
      for (var i = 0; i < all.length; i++) {
        var r = all[i].getBoundingClientRect();
        if (r.width < 100 || r.height < 300) continue;
        if (!best || r.width * r.height > best.a) { best = { el: all[i], a: r.width * r.height }; }
      }
      if (!best) return;
      var el = best.el;
      el.style.position = 'fixed';
      el.style.top = '0';
      el.style.left = '0';
      el.style.width = '100%';
      el.style.height = '100%';
      el.style.maxWidth = 'none';
      el.style.maxHeight = 'none';
    } catch (e) {}
  }

  function clean() {
    if (isBlobTop) {
      addStyle(document, innerCss, 'gcb-clean-css');
    } else {
      addStyle(document, outerCss, 'gcb-clean-css');
      healCanvas();
    }
  }

  clean();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', clean);
  }
  window.addEventListener('load', healCanvas);
})();`;

export const CLEANER_MIN_SCRIPT = `(function(){
  var outerCss = ${JSON.stringify(OUTER_CSS)};

  function addStyle(doc, css, id) {
    if (!doc || !doc.head) return false;
    if (id && doc.getElementById(id)) return true;
    var s = doc.createElement('style');
    s.type = 'text/css';
    if (id) s.id = id;
    s.textContent = css;
    doc.head.appendChild(s);
    return true;
  }

  function healTop() {
    try {
      if (window.location.protocol === 'blob:') return;
      if (!(document.querySelector('chat-app') || document.querySelector('chat-app-orchestrator'))) return;
      addStyle(document, 'chat-app, chat-app-orchestrator { padding-top: 0px !important; margin-top: 0px !important; }', 'gcb-canvas-heal-css');
      var best = null;
      var all = document.querySelectorAll('iframe');
      for (var i = 0; i < all.length; i++) {
        var r = all[i].getBoundingClientRect();
        if (r.width < 100 || r.height < 300) continue;
        if (!best || r.width * r.height > best.a) { best = { el: all[i], a: r.width * r.height }; }
      }
      if (!best) return;
      var el = best.el;
      el.style.position = 'fixed';
      el.style.top = '0';
      el.style.left = '0';
      el.style.width = '100%';
      el.style.height = '100%';
      el.style.maxWidth = 'none';
      el.style.maxHeight = 'none';
    } catch (e) {}
  }

  addStyle(document, outerCss, 'gcb-clean-css');
  healTop();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', healTop);
  }
  window.addEventListener('load', healTop);
})();`;

export const DOWNLOAD_SCRIPT = `(function(){
  if (window.__gcbDownloadSetup) return;
  window.__gcbDownloadSetup = true;

  var blobMap = {};

  var origCreateObjectURL = URL.createObjectURL;
  URL.createObjectURL = function(blob) {
    var url = origCreateObjectURL.apply(this, arguments);
    if (blob instanceof Blob) {
      blobMap[url] = blob;
    }
    return url;
  };

  var origRevokeObjectURL = URL.revokeObjectURL;
  URL.revokeObjectURL = function(url) {
    setTimeout(function() {
      delete blobMap[url];
      try { origRevokeObjectURL.call(URL, url); } catch(e){}
    }, 15000);
  };

  function post(m) {
    try {
      if (window.ReactNativeWebView && window.ReactNativeWebView.postMessage) {
        window.ReactNativeWebView.postMessage(m);
      }
    } catch (e) {}
  }

  function sanitize(s) {
    return String(s || '').replace(/[<>:|"?*\\/\\n\\r]+/g, '_').trim() || 'download';
  }

  function sendDownload(name, mime, b64) {
    name = sanitize(name);
    var msg = 'GDL|' + encodeURIComponent(name) + '|' + (mime || 'application/octet-stream') + '|' + b64;
    var CHUNK = 800000;
    if (msg.length > 1000000) {
      for (var i = 0; i < msg.length; i += CHUNK) {
        post('GDC|' + msg.slice(i, i + CHUNK));
      }
      post('GCDE|' + msg.length);
    } else {
      post(msg);
    }
  }

  function readBlobAndSend(blob, filename) {
    var reader = new FileReader();
    reader.onload = function() {
      var dataUrl = String(reader.result || '');
      var comma = dataUrl.indexOf(',');
      var b64 = comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
      sendDownload(filename || 'download', blob.type, b64);
    };
    reader.readAsDataURL(blob);
  }

  function handleBlobUrl(url, filename) {
    if (blobMap[url]) {
      readBlobAndSend(blobMap[url], filename);
      return;
    }
    try {
      fetch(url)
        .then(function(res) { return res.blob(); })
        .then(function(blob) { readBlobAndSend(blob, filename); })
        .catch(function(){});
    } catch(e){}
  }

  document.addEventListener('click', function(ev) {
    var target = ev.target;
    while (target && target !== document.body) {
      if (target.tagName === 'A') {
        var href = target.getAttribute('href') || target.href || '';
        var downloadName = target.getAttribute('download') || 'download';
        if (href.indexOf('blob:') === 0) {
          ev.preventDefault();
          handleBlobUrl(href, downloadName);
          return;
        }
        if (href.indexOf('data:') === 0) {
          ev.preventDefault();
          var i = href.indexOf(',');
          var mime = (href.slice(0, i).split(';')[0] || '').replace('data:', '');
          sendDownload(downloadName, mime, href.slice(i + 1));
          return;
        }
      }
      target = target.parentElement;
    }
  }, true);

  var origAnchorClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function() {
    var href = this.getAttribute('href') || this.href || '';
    var downloadName = this.getAttribute('download');
    if (href.indexOf('blob:') === 0) {
      handleBlobUrl(href, downloadName || 'download');
      return;
    }
    if (href.indexOf('data:') === 0) {
      var i = href.indexOf(',');
      var mime = (href.slice(0, i).split(';')[0] || '').replace('data:', '');
      sendDownload(downloadName || 'download', mime, href.slice(i + 1));
      return;
    }
    return origAnchorClick.apply(this, arguments);
  };
})();`;