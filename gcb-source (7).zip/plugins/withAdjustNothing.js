const { withAndroidManifest } = require('@expo/config-plugins');

function withAdjustNothing(config) {
  return withAndroidManifest(config, (manifestConfig) => {
    const application = manifestConfig.modResults.manifest.application?.[0];
    if (application && Array.isArray(application.activity)) {
      const mainActivity = application.activity.find((activity) => {
        const name = activity.$ ? activity.$['android:name'] : '';
        return name === '.MainActivity' || name.endsWith('MainActivity');
      });

      if (mainActivity) {
        // تنظیم رفتار کیبورد اندروید روی حالت قفل کامل (عدم جابه‌جایی و عدم تغییر سایز)
        mainActivity.$['android:windowSoftInputMode'] = 'adjustNothing';
      }
    }
    return manifestConfig;
  });
}

module.exports = withAdjustNothing;